<?php

class Rechargeurl {

 public static function rechargehistory($data)
 {
        $url = "http://localhost/restapi/recharge/history";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));                       
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $responsepurge = curl_exec($ch);
        return json_decode($responsepurge);

 }
 
 public static function rechargenumber($productid,$mobno,$amt,$id)
 {
  
		$authcode="8519fe9d959b425192";
		$product=$productid;
		$MobileNumber=$mobno;
		$Amount=$amt;
		$RequestId=$id;
		$url = "http://103.29.232.110:8089/Ezypaywebservice/PushRequest.aspx?AuthorisationCode=".$authcode."&product=".$product."&MobileNumber=".$MobileNumber."&Amount=".$Amount."&RequestId=".$RequestId."";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));                       
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $responsepurge = curl_exec($ch);
		$responce=explode('~',$responsepurge);
        return $responce[4];

 }
 
 
        
}